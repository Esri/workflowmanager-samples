# Name:        Branch Version Reconcile & Post using the ArcGIS Python API
#
# Purpose:      This tool performs the following functions:
#               - Creates the API GIS object
#               - Builds the appropriate service URLs needed to utilize the Version Manager and Version API submodules
#               - Reconciles version data and if there are no conflicts, posts to DEFAULT
#
# Author:      Tiffany Weintraub (tweintraub@esri.com) and Ken Galliher (kgalliher@esri.com)
#
# Created:     11/24/2020
# Updated:     8/1/2022
# 
# COPYRIGHT © 2022 Esri
# All material copyright ESRI, All Rights Reserved, unless otherwise specified.
# See https://github.com/Esri/workflowmanager-samples/blob/master/License.txt for details.
 
##-----------------------------------------------------------------------------------------------

##----------------- Modules -------------------------------------------------------------

# import modules
import arcpy, datetime, requests, os
import arcgis.features
from arcgis.gis import GIS
import Config


# Disable warnings
requests.packages.urllib3.disable_warnings()

##----------------------------- Input & Derived Parameters ----------------------------------------

fs_url = arcpy.GetParameter(0)
version_name_txt = arcpy.GetParameter(1)

if fs_url.endswith("FeatureServer"):
    base_url = os.path.dirname(fs_url)
else:
    base_url = os.path.dirname(os.path.dirname(fs_url))

#--------------------------------------------------------------------------------------------------

try:
    start_time = datetime.datetime.now()

    # Service URLs and GIS object
    arcpy.AddMessage(f"connecting to {Config.portal_params.portal_url}...")
    portal = GIS(
        url=Config.portal_params.portal_url,
        password=Config.portal_params.p_password,
        username=Config.portal_params.p_username,
    )

    # Create a dict of service urls
    services = ["FeatureServer", "VersionManagementServer"]
    service_urls = {url: base_url + '/' + url for url in services}

    # The Feature Server (service URL)
    version_mgmt_svc = service_urls["VersionManagementServer"]
    vms = arcgis.features._version.VersionManager(service_urls["VersionManagementServer"], portal)
    arcpy.AddMessage(f'Version Management Service: {vms}')

    # Check if the new version exists and get the fully qualified version name from the version's properties ('owner.versionName')
    _version = [x for x in vms.all if version_name_txt in x.properties.versionName]
    fq_version_name = _version[0].properties.versionName
    arcpy.AddMessage(f'Fully qualified version name: {fq_version_name}')

    # # Find and remove lock(s) for fully qualified version, if exists
    # with vms.get(fq_version_name, "read") as lock_version:   # use "read" to run start_reading
            
    #     lock_list = [v for v in vms.locks if fq_version_name == v.properties.versionName]

    #     if len(lock_list) > 0:
    #         # Remove locks on version
    #         vms.purge(fq_version_name)
    #         arcpy.AddMessage(f"Purged locks for version: {fq_version_name}")
    #     else:
    #         arcpy.AddMessage(f"No locks found for version {fq_version_name}")


    # Reconcile the version with Default
    with vms.get(fq_version_name, "edit") as version:  # use "edit" to run start_editing
        # Reconcile the version. Post if there are no conflicts detected.
        try:
            arcpy.AddMessage(f"Reconciling...")
            reconcile_res = version.reconcile(end_with_conflict=True, with_post=True)
            arcpy.AddMessage(f"Results of Reconcile & Post: {reconcile_res}")

            if not reconcile_res:
                arcpy.AddMessage(f"Reconciling the version {version.properties.versionName} failed.")
                raise Exception(f"Reconciling the version {version.properties.versionName} failed.")
                out_code = 1

            arcpy.AddMessage(f"Reconciled and posted version: {version.properties.versionName}")
            arcpy.AddMessage(f"Output Code: {reconcile_res}")
            out_code = 0

            arcpy.SetParameter(2, out_code)
            arcpy.AddMessage(out_code)

            end_time = datetime.datetime.now()
            elapsed_time = end_time - start_time
            arcpy.AddMessage(f"Dataset was locked for {elapsed_time.total_seconds()} secs")

            
        except Exception as ex:
            arcpy.AddMessage(str(ex))
            out_code = 1

except Exception as ex:
    arcpy.AddMessage(str(ex))
    out_code = 1