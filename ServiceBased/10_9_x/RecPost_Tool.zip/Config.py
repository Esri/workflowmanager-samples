class portal_params:
    url_scheme = "https://"
    portal_url = f"{url_scheme}<servername>/portal"
    p_username = 'portaladmin'
    p_password = 'password'


