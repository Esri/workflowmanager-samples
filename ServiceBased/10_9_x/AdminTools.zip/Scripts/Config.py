
class portal_params:
    url_scheme = "https://"
    portal_url = f"{url_scheme}servername.domain.com/portal"
    p_username = 'portaladmin'
    p_password = 'SuperSecret123'

class dest_portal_params:
    url_scheme = "https://"
    dest_portal_url = f"{url_scheme}servername.domain.com/portal"
    dest_username = 'portaladmin'
    dest_password = 'SuperSecret123'